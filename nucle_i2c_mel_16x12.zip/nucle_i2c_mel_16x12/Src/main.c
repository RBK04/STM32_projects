
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2019 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"

/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>

#define Melexis 0x66
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void offset_sp0(void);
void offset_sp1(void);
void k_ee(void);
void alpha(void);
void register_ee(void);
void ram(void);
void pixel_sp0(void);
void pixel_sp1(void);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
uint8_t dato_recibe_uart[1];
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  HAL_UART_Receive_DMA(&huart2,dato_recibe_uart,1);
  //uint8_t dato_send[12]= {0x9,0x01};
  //uint16_t direction = 0x800D;
  //HAL_I2C_Mem_Write(&hi2c1,(uint16_t)Melexis,direction,2,dato_send,2,100);
  while (1)
  {
	  HAL_GPIO_TogglePin(LD2_GPIO_Port,LD2_Pin);
		HAL_GPIO_TogglePin(LD2_GPIO_Port,LD2_Pin);
		if(dato_recibe_uart[0] == 'a'){
			dato_recibe_uart[0] = '\0';
			offset_sp0();
		}
		if(dato_recibe_uart[0]== 'b'){
			dato_recibe_uart[0] = '\0';
			offset_sp1();
		}
		if(dato_recibe_uart[0]== 'c'){
			dato_recibe_uart[0] = '\0';
			k_ee();
		}
		if(dato_recibe_uart[0]== 'd'){
			dato_recibe_uart[0] = '\0';
			alpha();
		}
		if(dato_recibe_uart[0]== 'e'){
			dato_recibe_uart[0] = '\0';
			register_ee();
		}
		if(dato_recibe_uart[0]== 'r'){
			dato_recibe_uart[0] = '\0';
			ram();
		}
		if(dato_recibe_uart[0]== 'p'){
			pixel_sp0();
			dato_recibe_uart[0] = '\0';
		}
		if(dato_recibe_uart[0]== 'q'){
			pixel_sp1();
			dato_recibe_uart[0] = '\0';
		}

  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL12;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* I2C1 init function */
static void MX_I2C1_Init(void)
{

  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x0000000D;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Analogue filter 
    */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Digital filter 
    */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**I2C Fast mode Plus enable 
    */
  __HAL_SYSCFG_FASTMODEPLUS_ENABLE(I2C_FASTMODEPLUS_I2C1);

}

/* USART2 init function */
static void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 250000;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel4_5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel4_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel4_5_IRQn);

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void offset_sp0(void){
	uint16_t direction;
	uint16_t dato_complete;
	uint8_t dato_recibe[3];
	char bufer[10];
	for(direction = 0x2440; direction<0x2500; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	sprintf(bufer,",\n");
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
}
void offset_sp1(void){
	uint16_t direction;
	uint16_t dato_complete;
	uint8_t dato_recibe[3];
	char bufer[10];
	for(direction = 0x2680; direction<0x2740; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	sprintf(bufer,",\n");
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
}

void k_ee(void){
	uint16_t direction;
	uint16_t dato_complete;
	uint8_t dato_recibe[3];
	char bufer[10];
	for(direction = 0x25C0; direction<0x2680; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	sprintf(bufer,",\n");
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
}
void alpha(void){
	uint16_t direction;
	uint16_t dato_complete;
	uint8_t dato_recibe[3];
	char bufer[10];
	for(direction = 0x2500; direction<0x25C0; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	sprintf(bufer,",\n");
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
}


void register_ee(void){
	uint16_t direction;
	uint16_t dato_complete;
	uint8_t dato_recibe[3];
	char bufer[10];

	direction = 0x2410;
	HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
	dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
	sprintf(bufer,",%X",dato_complete);
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);

	direction = 0x2411;
	HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
	dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
	sprintf(bufer,",%X",dato_complete);
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);

	direction = 0x2412;
	HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
	dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
	sprintf(bufer,",%X",dato_complete);
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);

	for(direction = 0x2415; direction < 0x2440;direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	sprintf(bufer,",\n");
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
}
void ram(void){
	uint16_t direction[8] = {0x8000, 0x800D, 0x05AA, 0x05A0, 0x0580, 0x058A, 0x0588, 0x05A8};
	uint16_t dato_complete;
	uint8_t dato_recibe[3];
	char bufer[10];

	for(int i = 0;i < 8 ;i++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction[i],2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	sprintf(bufer,",\n");
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
}

void pixel_sp0(void){
	uint16_t direction;
	char bufer[10];
	uint8_t dato_recibe[2];
	uint16_t dato_complete;
	for(direction = 0x0400; direction < 0x0420; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	for(direction = 0x0440; direction < 0x0460; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	for(direction = 0x0480; direction < 0x04A0; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	for(direction = 0x04C0; direction < 0x04E0; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	for(direction = 0x0500; direction < 0x0520; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	for(direction = 0x0540; direction < 0x0560; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	//HAL_UART_Transmit(&huart2,(uint8_t*)complete,(uint16_t)1536,(uint32_t)1);
	sprintf(bufer,",\n");
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
}

void pixel_sp1(void){
	uint16_t direction;
	char bufer[10];
	uint8_t dato_recibe[2];
	uint16_t dato_complete;
	for(direction = 0x0420; direction < 0x0440; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	for(direction = 0x0460; direction < 0x0480; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	for(direction = 0x04A0; direction < 0x04C0; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	for(direction = 0x04E0; direction < 0x0500; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	for(direction = 0x0520; direction < 0x0540; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	for(direction = 0x0560; direction < 0x0580; direction++){
		HAL_I2C_Mem_Read(&hi2c1,(uint16_t)Melexis,direction,2,dato_recibe,2,100);
		dato_complete = (dato_recibe[0]<<8)+dato_recibe[1];
		sprintf(bufer,",%X",dato_complete);
		HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);
	}
	//HAL_UART_Transmit(&huart2,(uint8_t*)complete,(uint16_t)1536,(uint32_t)1);
	sprintf(bufer,",\n");
	HAL_UART_Transmit(&huart2,(uint8_t*)bufer,(uint16_t)strlen(bufer),(uint32_t)1);

}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
