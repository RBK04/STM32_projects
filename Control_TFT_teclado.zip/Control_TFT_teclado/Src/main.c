
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2019 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_hal.h"

/* USER CODE BEGIN Includes */
#include "Intesc_Stdr_Types.h"
#include "ST7735_Driver.h"
#include "TFT_Ophyra.h"
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

DAC_HandleTypeDef hdac;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim3;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
char bufer1[25],bufer2[14],bufer3[14], bufer4[14],bufer5[14], bufer6[14];
char bufer7[14],bufer8[14],bufer9[14], bufer10[14],bufer11[14];

float Kp=1, Kd=0, Ki=0 ,P=0;
double volts , error_b=0 , V_d=0.1;
int analog, Time_b=0;
int i=0, j=0, temporal;
int digital[10];
double volts_b, escalar=0.980392156, N=20.0;
double PID, I=0, D=0, D_b, I_b, error;
float muestras[5000];
int l=0 , s=0, enviar=0;
U32 ColorLetra = 0xFFFFFF;
U32 ColorLinea = 0x66CCFF;
U32 ColorFondo = 0x000000;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM3_Init(void);
static void MX_ADC1_Init(void);
static void MX_DAC_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_TIM3_Init();
  MX_ADC1_Init();
  MX_DAC_Init();
  /* USER CODE BEGIN 2 */
  TFT_Init(0);
  TFT_BackLight(1);
  TFT_ClearDisplay(ColorFondo);

  TFT_PrintStr(20,2,"Variables de Control", ColorLetra, ColorFondo);
  TFT_PrintLine(0,0,159,0,ColorLinea);
  TFT_PrintLine(159,0,159,10,ColorLinea);
  TFT_PrintLine(159,10,0,10,ColorLinea);
  TFT_PrintLine(0,10,0,0,ColorLinea);
  TFT_PrintLine(0,10,0,127,ColorLinea);
  TFT_PrintLine(0,127,159,127,ColorLinea);
  TFT_PrintLine(159,127,159,10,ColorLinea);

  HAL_TIM_Base_Start_IT(&htim3);
  HAL_DAC_Start(&hdac,DAC_CHANNEL_1);
  HAL_DAC_SetValue(&hdac,DAC_CHANNEL_1,DAC_ALIGN_12B_R,50);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  TFT_PrintStr(2,40,"error:",ColorLetra,ColorFondo);
  TFT_PrintStr(2,50,"PID:",ColorLetra,ColorFondo);
  TFT_PrintStr(2,60,"V_deseado:",ColorLetra,ColorFondo);
  TFT_PrintStr(2,70,"P:",ColorLetra,ColorFondo);
  TFT_PrintStr(2,80,"D:",ColorLetra,ColorFondo);
  TFT_PrintStr(2,90,"analog:",ColorLetra,ColorFondo);

  Kp=1.0273; Kd=0.0661; Ki=0.3725;
  int bandera = 1;
  while (1)
  {
	  TFT_PrintStr(45,40,bufer1,ColorFondo,ColorFondo);
	  TFT_PrintStr(45,50,bufer2,ColorFondo,ColorFondo);
	  TFT_PrintStr(65,60,bufer3,ColorFondo,ColorFondo);
	  TFT_PrintStr(45,70,bufer4,ColorFondo,ColorFondo);
	  TFT_PrintStr(45,80,bufer5,ColorFondo,ColorFondo);
	  TFT_PrintStr(45,90,bufer6,ColorFondo,ColorFondo);
	  TFT_PrintStr(45,100,bufer7,ColorFondo,ColorFondo);
//	  TFT_PrintStr(70,100,bufer8,ColorFondo,ColorFondo);
//	  TFT_PrintStr(95,100,bufer9,ColorFondo,ColorFondo);
//	  TFT_PrintStr(45,110,bufer10,ColorFondo,ColorFondo);
//	  TFT_PrintStr(70,110,bufer11,ColorFondo,ColorFondo);

	  sprintf(bufer1,"%.4f",error);
	  sprintf(bufer2,"%.2f",PID);
	  sprintf(bufer3,"%.2f",V_d);
	  sprintf(bufer4,"%.2f",P);
	  sprintf(bufer5,"%.4f",D);
	  sprintf(bufer6,"%d",analog);
	  sprintf(bufer7,"%0.6f",escalar);
//	  sprintf(bufer8,"%d",digital[1]);
//	  sprintf(bufer9,"%d",digital[2]);
//	  sprintf(bufer10,"%d",digital[3]);
//	  sprintf(bufer11,"%d",digital[4]);

	  TFT_PrintStr(45,40,bufer1,ColorLetra,ColorFondo);
	  TFT_PrintStr(45,50,bufer2,ColorLetra,ColorFondo);
	  TFT_PrintStr(65,60,bufer3,ColorLetra,ColorFondo);
	  TFT_PrintStr(45,70,bufer4,ColorLetra,ColorFondo);
	  TFT_PrintStr(45,80,bufer5,ColorLetra,ColorFondo);
	  TFT_PrintStr(45,90,bufer6,ColorLetra,ColorFondo);
	  TFT_PrintStr(45,100,bufer7,ColorLetra,ColorFondo);
//	  TFT_PrintStr(70,100,bufer8,ColorLetra,ColorFondo);
//	  TFT_PrintStr(95,100,bufer9,ColorLetra,ColorFondo);
//	  TFT_PrintStr(45,110,bufer10,ColorLetra,ColorFondo);
//	  TFT_PrintStr(70,110,bufer11,ColorLetra,ColorFondo);

	  if(HAL_GPIO_ReadPin(Sw2_GPIO_Port,Sw2_Pin)==0 && bandera == 1){
		  HAL_GPIO_WritePin(GPIOE,Blue_Pin, GPIO_PIN_RESET);
		  //HAL_GPIO_WritePin(GPIOA,Step_Pin,GPIO_PIN_SET);
		  bandera = 0;
		  //I_b=0;
		  V_d=1;
		  HAL_Delay(300);
	  }
	  else if(HAL_GPIO_ReadPin(Sw2_GPIO_Port,Sw2_Pin)==0 && bandera == 0){
		  HAL_GPIO_WritePin(GPIOE,Blue_Pin, GPIO_PIN_SET);
		  //HAL_GPIO_WritePin(GPIOA,Step_Pin,GPIO_PIN_RESET);
		  bandera = 1;
		  //I_b=0;
		  V_d=0.1;
		  HAL_Delay(300);
	  }

	  if(HAL_GPIO_ReadPin(Sw3_GPIO_Port,Sw3_Pin)==0){
		  s=1;
		  Kp=1; Kd=0; Ki=0;
		  V_d=1;
		  if(enviar == 1){
			  for(int q=0; q<5001; q++){
				  sprintf(bufer1,"%.10f",muestras[q]);
				   //HAL_UART_Transmit();
			  }
			  enviar =0;
		  }
	  }
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Configure the main internal regulator output voltage 
    */
  __HAL_RCC_PWR_CLK_ENABLE();

  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 5;
  RCC_OscInitStruct.PLL.PLLN = 210;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV4;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* ADC1 init function */
static void MX_ADC1_Init(void)
{

  ADC_ChannelConfTypeDef sConfig;

    /**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion) 
    */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time. 
    */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* DAC init function */
static void MX_DAC_Init(void)
{

  DAC_ChannelConfTypeDef sConfig;

    /**DAC Initialization 
    */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**DAC channel OUT1 config 
    */
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* SPI1 init function */
static void MX_SPI1_Init(void)
{

  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM3 init function */
static void MX_TIM3_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 41;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 999;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, Blue_Pin|Red_Pin|Green_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, Negative_Pin|Step_Pin|TFT_BckLight_Pin|SPI_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, C1_Pin|C2_Pin|C3_Pin|C4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, TFT_RS_Pin|TFT_Reset_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : Blue_Pin Red_Pin Green_Pin */
  GPIO_InitStruct.Pin = Blue_Pin|Red_Pin|Green_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : Sw1_Pin */
  GPIO_InitStruct.Pin = Sw1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(Sw1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Negative_Pin Step_Pin TFT_BckLight_Pin SPI_CS_Pin */
  GPIO_InitStruct.Pin = Negative_Pin|Step_Pin|TFT_BckLight_Pin|SPI_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : F1_Pin F2_Pin F3_Pin F4_Pin */
  GPIO_InitStruct.Pin = F1_Pin|F2_Pin|F3_Pin|F4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : C1_Pin C2_Pin C3_Pin C4_Pin */
  GPIO_InitStruct.Pin = C1_Pin|C2_Pin|C3_Pin|C4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : Sw4_Pin Sw3_Pin Sw2_Pin */
  GPIO_InitStruct.Pin = Sw4_Pin|Sw3_Pin|Sw2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : TFT_RS_Pin TFT_Reset_Pin */
  GPIO_InitStruct.Pin = TFT_RS_Pin|TFT_Reset_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void TIM3_IRQHandler(void)
{
  /* USER CODE BEGIN TIM3_IRQn 0 */
	HAL_GPIO_TogglePin(Step_GPIO_Port, Step_Pin);
	for(i=0; i<11 ;i++){
		HAL_ADC_Start(&hadc1);
		digital[i] = HAL_ADC_GetValue(&hadc1);
		for(j=i-1; j>-1 ;j--){
			if(digital[j+1] > digital[j]){
				temporal = digital[j];
				digital[j] = digital[j+1];
				digital[j+1] = temporal;
			}
		}
	}
	volts = 0.0008056640625*digital[5];
	if(s==1){
		muestras[l] = volts;
		if(l==5000){
			s=0;
			enviar=1;
		}
	}
	error = V_d-volts;
	P= error*Kp;
	//escalar=(1/(1+(N*0.001)));
	D = escalar*(D_b+Kd*N*(error-error_b));
	I= I_b + Ki*0.001*error;
	D_b = D;
	I_b= I;
	volts_b = volts;
	error_b = error;
	PID = P+D+I;

	if(PID < 0){
		analog = (-1)*PID*1241.12;
		if(analog > 4095){
			analog = 4095;
		}
		HAL_DAC_SetValue(&hdac,DAC_CHANNEL_1,DAC_ALIGN_12B_R,analog);
		HAL_GPIO_WritePin(GPIOA,Negative_Pin, GPIO_PIN_SET);
	}
	else{
		analog = PID*1241.12;
		if(analog > 4095){
			analog = 4095;
		}
		HAL_DAC_SetValue(&hdac,DAC_CHANNEL_1,DAC_ALIGN_12B_R,analog);
		HAL_GPIO_WritePin(GPIOA,Negative_Pin, GPIO_PIN_RESET);
	}


  /* USER CODE END TIM3_IRQn 0 */
  HAL_TIM_IRQHandler(&htim3);
  /* USER CODE BEGIN TIM3_IRQn 1 */

  /* USER CODE END TIM3_IRQn 1 */
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
